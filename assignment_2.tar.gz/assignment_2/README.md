# TinyOS_project
use python 1.py to simulate